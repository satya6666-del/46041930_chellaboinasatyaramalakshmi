
public class CheckIncreaseNumber {
	int num=0;
	static int digit=0;
	static boolean flag=false;
	static boolean checkNumber(int n) {
		while(n>0)
		{
			digit=n%10;
			n=n/10;
			if(digit<n%10) {
				flag=true;
				break;
			}
		}
		return flag;
	}
	public static void main(String args[]) {
		checkNumber(1234);
		if(flag) {
			System.out.println("it is not increasing number");
		}
		else {
			System.out.println("it is a increasing number");
		}
	}

}
