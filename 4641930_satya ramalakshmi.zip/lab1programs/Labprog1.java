
public class Labprog1 {
	public static void main(String args[]) {
		int n=3;
		System.out.println(Cubesvalue(n));
	}
	public static int Cubesvalue(int n) {
		int sum=0;
		for(int a=1;a<=n;a++)
			sum+=a*a*a;
		return sum;
	}

}
