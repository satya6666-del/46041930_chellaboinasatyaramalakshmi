
public class CheckNumber {
	static int num;
	static boolean value;
	static boolean checkNumber(int n) {
		for(int i=0;i<n/2;i++) {
			num=n%2;
		}
		if(num==0) {
			value=true;
		}
		else
		{
			value=false;
		}
		return value;
	}
public static void main(String args[]) {
	System.out.println(checkNumber(8));
}
}
