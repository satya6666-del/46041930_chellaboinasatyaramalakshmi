package lab5;

public class Lab5program3 {
	
		public static void main(String args[]) {
			Lab5program3 le3 = new Lab5program3();
			try {
				System.out.println(le3.employeeSalary(50000));
				System.out.println(le3.employeeSalary(25000));
			}
			catch(EmployeeException e) {
				System.out.println(e);
			}
		}
		public float employeeSalary(float salary) throws EmployeeException {
			if(salary<30000) {
				throw new EmployeeException("Salary is less than 30000");
			}
			else
				System.out.println("Salary is...");
			return salary;
		}
	}

