package lab5;

public class Lab5program1 {
	

	
		public static void main(String args[]) {
			Lab5program1 lab = new Lab5program1();
			try {
				System.out.println(lab.validateAge(16));
				System.out.println(lab.validateAge(12));
			}
			catch(InvalidAge e) {
				System.out.println(e);
			}
		}
		public int validateAge(int age) throws InvalidAge {
			if(age<=15) {
				throw new InvalidAge("Age should be greater then 15");
			}
			else
				System.out.println("Age is valid");
			return age;
		}
	}

