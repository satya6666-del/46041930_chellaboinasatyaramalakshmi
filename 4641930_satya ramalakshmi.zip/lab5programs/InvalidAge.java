package lab5;

public class InvalidAge extends Exception{
	 
		public InvalidAge(String message) {
			super(message);
		}
	}


