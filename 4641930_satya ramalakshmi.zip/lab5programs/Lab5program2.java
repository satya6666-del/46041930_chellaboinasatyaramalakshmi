package lab5;

public class Lab5program2 {
	public static void main(String args[]) {
		Lab5program2 le2 = new Lab5program2();
		try {
			System.out.println(le2.validateName("satya", "s v"));
			System.out.println(le2.validateName(" ", " "));
		}
		catch(InvalidNameException e) {
			System.out.println(e);
		}
	}
	public String validateName(String firstName, String lastName) throws InvalidNameException {
		if(firstName == " " && lastName == " ") {
			throw new InvalidNameException("First name and last name should not be blank");
		}
		else 
			System.out.println("Name is valid");
		return "Name validation";
	}
}

