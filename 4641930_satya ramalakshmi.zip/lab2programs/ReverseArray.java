
	import java.util.Arrays;

	public class ReverseArray {
	  static void reverse(int s[],int n) {
		  int[] b=new int[n];
		  int j=n;
		  for(int i=0;i<n;i++) {
			  b[j-1]=s[i];
			  j=j-1;
		  }
		  System.out.println("After Reversing the Array");
		  for(int k=0;k<n;k++) {
			  System.out.println(b[k]);
		  }
		  Arrays.sort(s);
		  System.out.println("After Sorting the Array");
		  for(int p=0;p<s.length;p++) {
			  System.out.println(s[p]);
		  }
	}
	public static void main(String[] args) {
		int[] len= {20,10,50,5,70,90};
		reverse(len,len.length);
	}
	}


