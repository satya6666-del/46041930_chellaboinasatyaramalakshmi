import java.util.Arrays;


	public class Upperlow {
		void upperLowerSort(String[] n) {
			Arrays.sort(n);
			int s=(n.length);
			System.out.println(s);
			for(int i=0;i<s/2;i++)
			{
				System.out.println(n[i].toLowerCase());
			}
			for(int i=s/2;i<s;i++)
			{
				System.out.println(n[i].toUpperCase());
			}
			for(int i=0;i<n.length;i++)
				System.out.println(n[i]);
		}
		public static void main(String[] args){
			String str[]= {"ammu","satya","lakshmi","prasad"};
			Upperlow s2=new Upperlow();
			s2.upperLowerSort(str);
		}
	}


